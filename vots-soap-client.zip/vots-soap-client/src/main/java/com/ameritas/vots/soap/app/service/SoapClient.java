package com.ameritas.vots.soap.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.ameritas.vots.soap.app.bindings.CompletedContractingPacket;
import com.ameritas.vots.soap.app.bindings.CompletedTransactionResponseType;

@Service
public class SoapClient {

	@Autowired
	private Jaxb2Marshaller jaxb2Marshaller;

	private WebServiceTemplate webServiceTemplate;

	public CompletedTransactionResponseType getTransactionInfo(CompletedContractingPacket request) {
		webServiceTemplate = new WebServiceTemplate(jaxb2Marshaller);
		return (CompletedTransactionResponseType) webServiceTemplate.marshalSendAndReceive("http://localhost:8080/ws", request);
	}
}
