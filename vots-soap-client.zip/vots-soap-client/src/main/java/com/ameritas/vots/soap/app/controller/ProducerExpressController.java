package com.ameritas.vots.soap.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ameritas.vots.soap.app.bindings.CompletedContractingPacket;
import com.ameritas.vots.soap.app.bindings.CompletedTransactionResponseType;
import com.ameritas.vots.soap.app.service.SoapClient;

@RestController
@RequestMapping("/api/vots")
public class ProducerExpressController {

	@Autowired
    private SoapClient soapClient;

    @PostMapping("/item")
    public CompletedTransactionResponseType item(@RequestBody CompletedContractingPacket request){
        return soapClient.getTransactionInfo(request);
    }
	
}
