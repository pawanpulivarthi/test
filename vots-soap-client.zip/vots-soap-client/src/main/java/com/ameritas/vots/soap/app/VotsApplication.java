package com.ameritas.vots.soap.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.ameritas.vots.soap.app")
public class VotsApplication {

	
	public static void main(String[] args) {

		SpringApplication.run(VotsApplication.class, args);
	}

}
